function returnString = createPackage(name)
    returnString = ['package ' char(name) ';\n'];
end

