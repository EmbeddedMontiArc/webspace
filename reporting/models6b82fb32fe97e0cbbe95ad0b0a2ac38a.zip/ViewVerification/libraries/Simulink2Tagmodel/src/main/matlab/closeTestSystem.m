function closeTestSystem
    close_system('Oeffentlicher_Demonstrator_FAS_v04');
end

