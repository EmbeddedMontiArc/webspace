function init
    addpath('S2TM');
    addpath('SEFPV');
    addpath('SEFPV/OOImplementation');
    addpath('../resources');
end