function path = getDefaultPath
%GETDEFAULTPATH Summary of this function goes here
%   Detailed explanation goes here
    path = pwd;
end

