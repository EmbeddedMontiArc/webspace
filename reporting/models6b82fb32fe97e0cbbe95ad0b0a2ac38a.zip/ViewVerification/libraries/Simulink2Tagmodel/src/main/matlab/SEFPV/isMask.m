function isMask = isMask(blockPath)
    isMask = strcmp(get_param(blockPath,'Mask'), 'on');
end

