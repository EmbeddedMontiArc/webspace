function indentation = indent(s)
%INDENT indents the string s.
    indentation = ['\t' s];
end

