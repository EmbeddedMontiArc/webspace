function returnString = endTagModel
    returnString = '}\n';
end

