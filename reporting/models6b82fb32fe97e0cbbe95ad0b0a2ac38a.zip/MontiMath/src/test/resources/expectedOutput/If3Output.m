package expectedOutput;


script If3Output
	Q cond1 = 1/1;
	Q cond2 = -1/1;
	Q result = -1/1;
	B bool = 0;
end
