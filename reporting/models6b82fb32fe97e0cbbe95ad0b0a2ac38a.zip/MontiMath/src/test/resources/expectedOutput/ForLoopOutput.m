package expectedOutput;


script ForLoopOutput
	Q sum = 3840/1;
end
