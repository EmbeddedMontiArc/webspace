package expectedOutput;


script SolEquOutput
	Q^{3,1} A = [3/11;1/11;7/22];
	Q^{3,1} Bmat = [3/11;1/11;7/22];
end
