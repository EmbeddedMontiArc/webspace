package expectedOutput;


script IfOutput
	Q cond = 2/1;
	Q result = 0/1;
end
