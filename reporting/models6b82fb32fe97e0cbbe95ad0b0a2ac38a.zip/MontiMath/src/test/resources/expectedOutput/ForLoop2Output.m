package expectedOutput;


script ForLoop2Output
	Q^{1,5} c = [1/1m,3/1m,5/1m,7/1m,9/1m];
	Q x = 5/1;
	Q y = 625/1m^2;
	Q z = 125/1m;
end
