package symtab;

script ComplexAssignmentTest

C A = 3 + 4i;

end
